using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;

public class FruitSpawner : MonoBehaviour
{
    public GameObject[] fruitPrefabs;           // tempat prefab buah (misal Apple, Banana, Grape)
    public ARRaycastManager raycastManager;     // biar bisa raycast ke permukaan AR
    public Camera arCamera;                     // kamera AR kamu (Main Camera)
    public float spawnInterval = 2f;            // waktu antar spawn
    public int maxFruits = 5;                   // batas buah yang bisa muncul bersamaan

    private float timer = 0f;
    private List<GameObject> spawnedFruits = new List<GameObject>();
    private static List<ARRaycastHit> hits = new List<ARRaycastHit>();

    void Update()
    {
        // hitung waktu antar spawn
        timer += Time.deltaTime;

        // spawn buah tiap beberapa detik
        if (timer >= spawnInterval && spawnedFruits.Count < maxFruits)
        {
            SpawnFruit();
            timer = 0f;
        }

        // deteksi sentuhan layar
        if (Input.touchCount > 0)
        {
            Touch touch = Input.GetTouch(0);

            if (touch.phase == TouchPhase.Began)
            {
                Ray ray = arCamera.ScreenPointToRay(touch.position);
                RaycastHit hit;

                if (Physics.Raycast(ray, out hit))
                {
                    if (hit.transform.CompareTag("Fruit"))
                    {
                        Destroy(hit.transform.gameObject);
                        spawnedFruits.Remove(hit.transform.gameObject);
                    }
                }
            }
        }
    }

    void SpawnFruit()
    {
        // ambil posisi acak di layar
        Vector2 screenPos = new Vector2(Random.Range(0.2f, 0.8f) * Screen.width,
                                        Random.Range(0.3f, 0.8f) * Screen.height);

        // raycast ke permukaan AR
        if (raycastManager.Raycast(screenPos, hits, TrackableType.PlaneWithinPolygon))
        {
            Pose hitPose = hits[0].pose;
            GameObject fruitPrefab = fruitPrefabs[Random.Range(0, fruitPrefabs.Length)];

            GameObject spawned = Instantiate(fruitPrefab, hitPose.position, Quaternion.identity);
            spawnedFruits.Add(spawned);

            // otomatis hilang setelah beberapa detik
            Destroy(spawned, 6f);
        }
    }
}
