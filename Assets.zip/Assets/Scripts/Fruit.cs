using UnityEngine;

public class Fruit : MonoBehaviour
{
    public int scoreValue = 10;                     // nilai skor setiap buah
    public ParticleSystem popEffect;                // efek partikel (nanti dihubungkan di Unity)

    void OnMouseDown()
    {
        // tambahkan skor
        ScoreManager.instance.AddScore(scoreValue);

        // munculkan efek partikel di posisi buah
        if (popEffect != null)
            Instantiate(popEffect, transform.position, Quaternion.identity);

        // hapus buah setelah di-tap
        Destroy(gameObject);
    }
}
